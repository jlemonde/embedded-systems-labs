/* Source File: nested_loops.c
   Description:  Creates a simple illustration of processor usage 
   data for display with the Lauterbach TRACE32 IDE. */

void loop_c(int count_c)
{
    int iterator;
    
    for (iterator=0; iterator < 10000; iterator++)
    {
        count_c++;
    }
}

void loop_b(int count_b)
{
    int iterator;
    
    for (iterator=0; iterator < 10000; iterator++)
    {
        count_b++;
        loop_c(count_b);
    }
}


void loop_a(int count_a)
{
    int iterator;
    
    for (iterator=0; iterator < 10000; iterator++)
    {
        count_a++;
        loop_b(count_a);
    }
}

int main()
{
  static int count_main = 0;
  
  loop_a(count_main);
  while(1);
  
  return 0;
}
