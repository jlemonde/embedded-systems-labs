Important Notice

In order to run these examples, use the script.do ModelSim simulation script provided the sub directories. These are the steps:

1. Start ModelSim software.
2. On the File menu click Change Directory.
3. Navigate to <working_directory>\<related example>\ and click OK.
4. On the Compile menu, click Compile Options.
5. Click the Verilog & System Verilog tab.
6. In the Language Syntax box, select Use SystemVerilog and click OK.
7. On the File menu click Load.
8. Navigate to <working_directory>\<related example>\ and choose script.do and click Open.
