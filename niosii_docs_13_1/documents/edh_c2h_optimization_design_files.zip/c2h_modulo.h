/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/


#ifndef _C2H_MODULO_H_
#define _C2H_MODULO_H_

/* Author:  JCJB
 * Date:  June 7th, 2006
 * 
 * Usage Information:
 * -----------------
 * 
 * To use the modulo code located in this file simply include it in the source
 * file that you are accelerating (#include "c2h_modulo.h").  The following list
 * shows each modulo algorithm available and what macro to use.
 * 
 * 
 * 8 Bit:
 * 
 * Unsigned char numerator, unsigned char denominator, unsigned char remainder
 * Use --> u8_mod_u8(numerator, denominator, remainder)
 * 
 * Char numerator, char denominator, char remainder
 * Use --> s8_mod_s8(numerator, denominator, remainder)
 * 
 * 
 * 16 Bit:
 * 
 * Unsigned short numerator, unsigned short denominator, unsigned short remainder
 * Use --> u16_mod_u16(numerator, denominator, remainder)
 * 
 * Short numerator, short denominator, short remainder 
 * Use --> s16_mod_s16(numerator, denominator, remainder)
 * 
 * 
 * 32 Bit:
 * 
 * Unsigned long numerator, unsigned long denominator, unsigned long remainder
 * Use --> u32_mod_u32(numerator, denominator, remainder)
 * 
 * Long numerator, long denominator, long remainder 
 * Use --> s32_mod_s32(numerator, denominator, remainder)
 * 
 * 
 * 64 Bit:
 * 
 * Unsigned long long numerator, unsigned long long denominator, unsigned long long remainder
 * Use --> u64_mod_u64(numerator, denominator, remainder)
 * 
 * Long long numerator, long long denominator, long long remainder 
 * Use --> s64_mod_s64(numerator, denominator, remainder)
 * 
 * -----------------------------------------------------------------------------
 * 
 * The latency of the modulo calculation created is a function of the input
 * data size.  For a modulo of 'n' bit values the total latency of the remainder
 * calculation will be 'n' + 2 clock cycles. The only value modified by these
 * macros is the remainder value.
 * 
 */


/* u8%u8=u8 */
#define u8_mod_u8(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned char numerator_copy = (numerator) << 1; \
  volatile unsigned char residue = (numerator) >> 7; \
  do { \
    residue = ((residue - ((residue>=(denominator))? (denominator):0))<<1) | (numerator_copy>>7); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 8); \
  (remainder) = (((denominator) > (numerator)) || ((denominator) == 0))? (numerator) : residue>>1; \
}


/* s8%s8=s8 */
#define s8_mod_s8(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned char numerator_copy = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) << 1; \
  volatile unsigned char denominator_copy = (((denominator)&0x80) == 0x80)? (~(denominator))+1:(denominator); \
  volatile unsigned char residue = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) >> 7; \
  do { \
    residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0))<<1) | (numerator_copy>>7); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 8); \
  (remainder) = (((numerator)&0x80)==0x80)? ((~(residue>>1)) + 1) : (residue>>1); \
}


/* u16%u16=u16 */
#define u16_mod_u16(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned short numerator_copy = (numerator) << 1; \
  volatile unsigned short residue = (numerator) >> 15; \
  do { \
    residue = ((residue - ((residue>=(denominator))? (denominator):0))<<1) | (numerator_copy>>15); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 16); \
  (remainder) = (((denominator) > (numerator)) || ((denominator) == 0))? (numerator) : residue>>1; \
}

/* s16%s16=s16 */
#define s16_mod_s16(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned short numerator_copy = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) << 1; \
  volatile unsigned short denominator_copy = (((denominator)&0x8000) == 0x8000)? (~(denominator))+1:(denominator); \
  volatile unsigned short residue = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) >> 15; \
  do { \
    residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0))<<1) | (numerator_copy>>15); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 16); \
  (remainder) = (((numerator)&0x8000)==0x8000)? ((~(residue>>1)) + 1) : (residue>>1); \
}

/* u32%u32=u32 */
#define u32_mod_u32(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned long numerator_copy = (numerator) << 1; \
  volatile unsigned long residue = (numerator) >> 31; \
  do { \
    residue = ((residue - ((residue>=(denominator))? (denominator):0))<<1) | (numerator_copy>>31); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 32); \
  (remainder) = (((denominator) > (numerator)) || ((denominator) == 0))? (numerator) : residue>>1; \
}

/* s32%s32=s32 */
#define s32_mod_s32(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned long numerator_copy = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) << 1; \
  volatile unsigned long denominator_copy = (((denominator)&0x80000000) == 0x80000000)? (~(denominator))+1:(denominator); \
  volatile unsigned long residue = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) >> 31; \
  do { \
    residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0))<<1) | (numerator_copy>>31); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 32); \
  (remainder) = (((numerator)&0x80000000)==0x80000000)? ((~(residue>>1)) + 1) : (residue>>1); \
}

/* u64%u64=u64 */
#define u64_mod_u64(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned long long numerator_copy = (numerator) << 1; \
  volatile unsigned long long residue = (numerator) >> 63; \
  do { \
    residue = ((residue - ((residue>=(denominator))? (denominator):0))<<1) | (numerator_copy>>63); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 64); \
  (remainder) = (((denominator) > (numerator)) || ((denominator) == 0))? (numerator) : residue>>1; \
}

/* s64%s64=s64 */
#define s64_mod_s64(numerator, denominator, remainder) \
{ \
  volatile unsigned char bit_pos = 0; \
  volatile unsigned long long numerator_copy = ((((numerator)&0x8000000000000000) == 0x8000000000000000)? (~(numerator))+1:(numerator)) << 1; \
  volatile unsigned long long denominator_copy = (((denominator)&0x8000000000000000) == 0x8000000000000000)? (~(denominator))+1:(denominator); \
  volatile unsigned long long residue = ((((numerator)&0x8000000000000000) == 0x8000000000000000)? (~(numerator))+1:(numerator)) >> 63; \
  do { \
    residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0))<<1) | (numerator_copy>>63); \
    numerator_copy = numerator_copy << 1; \
    bit_pos++; \
  } while(bit_pos < 64); \
  (remainder) = (((numerator)&0x8000000000000000)==0x8000000000000000)? ((~(residue>>1)) + 1) : (residue>>1); \
}

#endif /* _C2H_MODULO_H_ */
