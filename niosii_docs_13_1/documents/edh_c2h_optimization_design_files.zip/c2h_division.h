/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/

#ifndef _C2H_DIVISION_H_
#define _C2H_DIVISION_H_

/* Author:  JCJB
 * Date:  June 7th, 2006
 * 
 * Usage Information:
 * -----------------
 * 
 * To use the division code located in this file simply include it in the source
 * file that you are accelerating (#include "c2h_division.h").  The following
 * list shows each division algorithm available and what macro to use.
 * 
 * 
 * 8 Bit:
 * 
 * Unsigned char numerator, unsigned char denominator, unsigned char quotient
 * Use --> u8_div_u8(numerator, denominator, quotient)
 * 
 * Char numerator, char denominator, char quotient
 * Use --> s8_div_s8(numerator, denominator, quotient)
 * 
 * 
 * 16 Bit:
 * 
 * Unsigned short numerator, unsigned short denominator, unsigned short quotient
 * Use --> u16_div_u16(numerator, denominator, quotient)
 * 
 * Short numerator, short denominator, short quotient 
 * Use --> s16_div_s16(numerator, denominator, quotient)
 * 
 * 
 * 32 Bit:
 * 
 * Unsigned long numerator, unsigned long denominator, unsigned long quotient
 * Use --> u32_div_u32(numerator, denominator, quotient)
 * 
 * Long numerator, long denominator, long quotient 
 * Use --> s32_div_s32(numerator, denominator, quotient)
 * 
 * 
 * 64 Bit:
 * 
 * Unsigned long long numerator, unsigned long long denominator, unsigned long long quotient
 * Use --> u64_div_u64(numerator, denominator, quotient)
 * 
 * Long long numerator, long long denominator, long long quotient 
 * Use --> s64_div_s64(numerator, denominator, quotient)
 * 
 * -----------------------------------------------------------------------------
 * 
 * The latency of the dividers created is a function of the input data size.
 * For a division of 'n' bit values the total latency of the division will be
 * 'n' + 2 or 3 clock cycles depending on the usage of "match_gcc" (read below
 * to learn more).  The only value modified by these macros is the quotient
 * value.
 * 
 */


#define match_gcc /* comment out this line if you don't care about matching gcc */

/* yes-unsigned:  number/number = quotient, number/0 = 0, 0/0 = 1
 * yes-signed:    number/number = quotient, number/0 = 0, 0/0 = 1
 * no-unsigned:   number/number = quotient, number/0 = max, 0/0 = max
 * no-signed:     number/number = quotient, +number/0 = 1, -number/0 = -1, 0/0 = -1
 * 
 * Note:  don't define match_gcc if you want the fastest divider possible.  The difference between
 * the two implmentations is strictly how values for infinity, not a number are handled.  These are
 * always caused by division of zero.  Division by zero should always avoided in the algorithm
 * since mathematically speaking neither this hardware nor the gcc math functions can properly
 * store divisions by zero as an integer result.  Therefore one should leave match_gcc undefined since
 * it only masks an error in the algorithm.
 * 
 * When you divide the largest negative value by the smallest negative number possible by (-1) you have a positive result that
 * can't be represented as a positive value.  This is because zero is considered to be a positive
 * value in 2's compliment format and this error is called divider overflow.  The division will occur
 * properly in hardware however when the result is store the msb (sign bit) is a part of the
 * magnitude which will be interpreted by Nios II or the acccelerator incorrectly.  In order to store
 * this result correctly the next largest data type would need to be used so that the sign bit can be
 * promoted (this is not supported in this file but can be easily created modifying the code below).
 */



/* u8/u8 = u8 */
#ifdef match_gcc
  #define u8_div_u8(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned char numerator_copy = (numerator) << 1; \
    volatile unsigned char residue = (numerator) >> 7; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 7); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while (bit_pos < 8); \
    (quotient) = ((denominator) != 0)? (quotient) : \
                  ((numerator) == 0)? 1 : 0; \
  }
#else 
  #define u8_div_u8(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned char numerator_copy = (numerator) << 1; \
    volatile unsigned char residue = (numerator) >> 7; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 7); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 8); \
  }
#endif


/* s8/s8=s8 */
#ifdef match_gcc
  #define s8_div_s8(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned char quotient_copy; \
    volatile unsigned char numerator_copy = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned char denominator_copy = (((denominator)&0x80) == 0x80)? (~(denominator))+1:(denominator); \
    volatile unsigned char residue = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) >> 7; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 7); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 8); \
    (quotient) = ((denominator) == 0)? (((numerator) == 0)? 1:0) : \
                    (((((numerator)&0x80) ^ ((denominator)&0x80)) == 0x80)? (~quotient_copy)+1: quotient_copy);\
  }
#else
  #define s8_div_s8(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned char quotient_copy; \
    volatile unsigned char numerator_copy = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned char denominator_copy = (((denominator)&0x80) == 0x80)? (~(denominator))+1:(denominator); \
    volatile unsigned char residue = ((((numerator)&0x80) == 0x80)? (~(numerator))+1:(numerator)) >> 7; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 7); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 8); \
    (quotient) = ((((numerator)&0x80) ^ ((denominator)&0x80)) == 0x80)? (~quotient_copy)+1: quotient_copy;\
  }
#endif



/* u16/u16=u16 */
#ifdef match_gcc
  #define u16_div_u16(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned short numerator_copy = (numerator) << 1; \
    volatile unsigned short residue = (numerator) >> 15; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 15); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 16); \
    (quotient) = ((denominator) != 0)? (quotient) : \
                  ((numerator) == 0)? 1 : 0; \
  }
#else 
  #define u16_div_u16(numerator, denominator, quotient) \
  { \
    volatile unsigned short bit_pos = 0; \
    volatile unsigned short numerator_copy = (numerator) << 1; \
    volatile unsigned short residue = (numerator) >> 15; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 15); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 16); \
  }
#endif


/* s16/s16=s16 */
#ifdef match_gcc
  #define s16_div_s16(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned short quotient_copy; \
    volatile unsigned short numerator_copy = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned short denominator_copy = (((denominator)&0x8000) == 0x8000)? (~(denominator))+1:(denominator); \
    volatile unsigned short residue = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) >> 15; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 15); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 16); \
    (quotient) = ((denominator) == 0)? (((numerator) == 0)? 1:0) : \
                    (((((numerator)&0x8000) ^ ((denominator)&0x8000)) == 0x8000)? (~quotient_copy)+1: quotient_copy);\
  }
#else
  #define s16_div_s16(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned short quotient_copy; \
    volatile unsigned short numerator_copy = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned short denominator_copy = (((denominator)&0x8000) == 0x8000)? (~(denominator))+1:(denominator); \
    volatile unsigned short residue = ((((numerator)&0x8000) == 0x8000)? (~(numerator))+1:(numerator)) >> 15; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 15); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 16); \
    (quotient) = ((((numerator)&0x8000) ^ ((denominator)&0x8000)) == 0x8000)? (~quotient_copy)+1: quotient_copy;\
  }
#endif


/* u32/u32=u32 */
#ifdef match_gcc
  #define u32_div_u32(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long numerator_copy = (numerator) << 1; \
    volatile unsigned long residue = (numerator) >> 31; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 31); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 32); \
    (quotient) = ((denominator) != 0)? (quotient) : \
                  ((numerator) == 0)? 1 : 0; \
  }
#else 
  #define u32_div_u32(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long numerator_copy = (numerator) << 1; \
    volatile unsigned long residue = (numerator) >> 31; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 31); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 32); \
  }
#endif

/* s32/s32=s32 */
#ifdef match_gcc
  #define s32_div_s32(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long quotient_copy; \
    volatile unsigned long numerator_copy = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned long denominator_copy = (((denominator)&0x80000000) == 0x80000000)? (~(denominator))+1:(denominator); \
    volatile unsigned long residue = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) >> 31; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 31); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 32); \
    (quotient) = ((denominator) == 0)? (((numerator) == 0)? 1:0) : \
                    (((((numerator)&0x80000000) ^ ((denominator)&0x80000000)) == 0x80000000)? (~quotient_copy)+1: quotient_copy);\
  }
#else
  #define s32_div_s32(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long quotient_copy; \
    volatile unsigned long numerator_copy = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned long denominator_copy = (((denominator)&0x80000000) == 0x80000000)? (~(denominator))+1:(denominator); \
    volatile unsigned long residue = ((((numerator)&0x80000000) == 0x80000000)? (~(numerator))+1:(numerator)) >> 31; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 31); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 32); \
    (quotient) = ((((numerator)&0x80000000) ^ ((denominator)&0x80000000)) == 0x80000000)? (~quotient_copy)+1: quotient_copy;\
  }
#endif


/* u64/u64=u64 */
#ifdef match_gcc
  #define u64_div_u64(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long long numerator_copy = (numerator) << 1; \
    volatile unsigned long long residue = (numerator) >> 63; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 63); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 64); \
    (quotient) = ((denominator) != 0)? (quotient) : \
                  ((numerator) == 0)? 1 : 0; \
  }
#else 
  #define u64_div_u64(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long long numerator_copy = (numerator) << 1; \
    volatile unsigned long long residue = (numerator) >> 63; \
    (quotient) = 0; \
    do { \
      (quotient) = ((quotient)<<1) | ((residue>=(denominator))? 1:0); \
      residue = ((residue - ((residue>=(denominator))? (denominator):0)) << 1) | (numerator_copy >> 63); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 64); \
  }
#endif

/* s64/s64=s64 */
#ifdef match_gcc
  #define s64_div_s64(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long long quotient_copy; \
    volatile unsigned long long numerator_copy = ((((numerator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned long long denominator_copy = (((denominator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(denominator))+1:(denominator); \
    volatile unsigned long long residue = ((((numerator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(numerator))+1:(numerator)) >> 63; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 63); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 64); \
    (quotient) = ((denominator) == 0)? (((numerator) == 0)? 1:0) : \
                    (((((numerator)&0x8000000000000000LL) ^ ((denominator)&0x8000000000000000LL)) == 0x8000000000000000LL)? (~quotient_copy)+1: quotient_copy);\
  }
#else
  #define s64_div_s64(numerator, denominator, quotient) \
  { \
    volatile unsigned char bit_pos = 0; \
    volatile unsigned long long quotient_copy; \
    volatile unsigned long long numerator_copy = ((((numerator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(numerator))+1:(numerator)) << 1; \
    volatile unsigned long long denominator_copy = (((denominator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(denominator))+1:(denominator); \
    volatile unsigned long long residue = ((((numerator)&0x8000000000000000LL) == 0x8000000000000000LL)? (~(numerator))+1:(numerator)) >> 63; \
    quotient_copy = 0; \
    do { \
      quotient_copy = (quotient_copy<<1) | ((residue>=denominator_copy)? 1:0); \
      residue = ((residue - ((residue>=denominator_copy)? denominator_copy:0)) << 1) | (numerator_copy >> 63); \
      numerator_copy = numerator_copy << 1; \
      bit_pos++; \
    } while(bit_pos < 64); \
    (quotient) = ((((numerator)&0x8000000000000000LL) ^ ((denominator)&0x8000000000000000LL)) == 0x8000000000000000LL)? (~quotient_copy)+1: quotient_copy;\
  }
#endif


#endif /* _C2H_DIVISION_H_ */
