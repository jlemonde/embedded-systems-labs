/****************************************************************************
 * Copyright � 2006 Altera Corporation, San Jose, California, USA.           *
 * All rights reserved. All use of this software and documentation is        *
 * subject to the License Agreement located at the end of this file below.   *
 ****************************************************************************/
/*****************************************************************************
*  File: external_boot.c
*
*  Purpose: This is an example of some code that could run on an external
*  processor to control the booting of a Nios II processor.  Using a 
*  PIO and the cpu_resetrequest signal, this routine holds the main Nios II 
*  processor in reset while it copies an application from a boot record 
*  in flash to RAM.  It then calls ReleaseMainCPU(), which calculates the 
*  entry point of the application, constructs a Nios II instruction which 
*  branches to that entry point, then writes the instruction to the Nios II 
*  reset address and releases the Nios II from reset.
*
*  This example code is of course predicated on the fact that the main Nios II
*  CPU's reset address is set to some volatile memory (RAM).  Otherwise, we 
*  cant write an instruction to the reset address.
*  
*****************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "external_boot.h"
#include "system.h"
#include "alt_types.h"
#include "io.h"

/*
 * These defines locate our application image in the flash memory.
 */
#define BOOT_IMAGE_1_OFFSET  ( 0x00000000 )
#define BOOT_IMAGE_1_ADDR  ( EXT_FLASH_BASE + BOOT_IMAGE_1_OFFSET )

/*
 * Here we define what the reset values are for our PIO connected
 * to the main CPU's cpu_resetrequest line.
 */
#define RESET_ACTIVE 0x1
#define RESET_INACTIVE 0x0

/*
 * This is the reset address of our main CPU for which we're
 * loading application code.  There's not really any place handy
 * that we can obtain this value automatically, so you'll have to 
 * plug it in here by hand.
 */
#define MAIN_CPU_RESET_ADDR 0x04000000

/*
 * Globally accessable variable.
 */
void *flash_image_ptr_1 = (void*)BOOT_IMAGE_1_ADDR;


/*****************************************************************************
*  Function: alt_main
*
*  Purpose: This routine loads an application to RAM from flash, then calls
*  ReleaseMainCPU() to handoff execution to start the main Nios II CPU.
*
*****************************************************************************/
int alt_main(void)
{

  alt_u32 entry_point;
  int temp;
  
  // Before getting started, we need to place and hold the main Nios II CPU in reset
  
  // But first we need to clear the edge capture register in the PIO, so we 
  // can see when the CPU actually achieves reset (using the cpu_resettaken pin)
  IOWR( MAIN_CPU_RESET_PIO_BASE, 0, RESET_INACTIVE );
  IOWR( MAIN_CPU_RESET_PIO_BASE, 3, 0 ); // capture register is at offset 3.
  
  // Now we try to reset the main CPU by setting the cpu_resetrequest pin high.
  IOWR( MAIN_CPU_RESET_PIO_BASE, 0, RESET_ACTIVE );
  
  // Here we wait for the edge capture register of the PIO to show us that 
  // the cpu_resettaken pin toggled high.
  temp = IORD( MAIN_CPU_RESET_PIO_BASE, 3 );
  do
  {
    temp = IORD( MAIN_CPU_RESET_PIO_BASE, 3 );
  } while( temp == 0x0 );
  
  // Now load the application from the boot record in flash.
  if( (entry_point = LoadFlashImage(1)) )  // load the image
  {
    // Release the main CPU from reset now that it has code to run.
    ReleaseMainCPU((void(*)(void))(entry_point));
  }
  else
  {
    // There was no image at that offset, so we'll just trap.
    while(1);
  }
  
  // All done, time to exit.
  exit(0);
}

/*****************************************************************************
*  Function: ReleaseMainCPU
*
*  Purpose: This is where the interesting stuff happens.  At this point we've
*  copied an application to the main Nios II program memory and we're holding
*  the CPU in reset.  We want to release it from reset so it can run the
*  application, only the application's entry point may not be at the CPU's 
*  reset address.  Luckily we have the entry point from the boot record, 
*  passed in here as the function pointer "entry_point".  We compare the
*  entry point to the CPU's reset address and calculate how far the CPU has
*  to branch to get there.  From that information, we construct a Nios II 
*  instruction that jumps the appropriate distance, then stuff it into memory
*  at the main CPU's reset address.  We release the CPU from reset, and if all
*  goes well, it executes the branch instruction we put at its reset address
*  and branches to the application's entry point, successfully launching the 
*  application.
*
*****************************************************************************/
void ReleaseMainCPU(void entry_point(void))
{
  int offset;
  unsigned int branch_instruction;

  // Calculate the offset the main cpu needs to jump from its reset address
  offset = (int)entry_point - MAIN_CPU_RESET_ADDR;
  
  // We only need to formulate a branch instruction if the the reset address 
  // does not already point to the entry point of the application. If the 
  // reset address already points to the application entry point, we can just 
  // release the main Nios II CPU from reset and everything should be happy.
  if( offset )
  { 
    // Now construct the appropriate branch instruction "br" we need to stuff 
    // into the main cpu reset address.  The relative offset we use for the 
    // instruction must be 4 bytes less than the actual entry point because
    // that is how Nios II defines the "br" instruction.

    // Branch instruction encoding
    //  31  29  27  25  23  21  19  17  15  13  11  09  07  05  03  01 
    //    30  28  26  24  22  20  18  16  14  12  10  08  06  04  02  00
    //  ----------------------------------------------------------------
    // |    0    |    0    |    16-bit relative jump -4    |   0x06     |
    //  ----------------------------------------------------------------
    branch_instruction = ((offset - 4) << 6) | 0x6;

  
    // Write the instruction to the main CPU reset address
    IOWR(MAIN_CPU_RESET_ADDR, 0, branch_instruction);
  }
  // Now we can release the main CPU from reset
  IOWR( MAIN_CPU_RESET_PIO_BASE, 0, RESET_INACTIVE );
   
  // We're done.  
  return;

}


/*****************************************************************************
*  Function: CopyFromFlash
*
*  Purpose:  This subroutine copies data from a flash memory to a buffer
*  The function uses the appropriate copy routine for the flash that is
*  defined by FLASH_TYPE.  EPCS devices cant simply be read from using
*  memcpy().
*
*****************************************************************************/
void* CopyFromFlash( void * dest, const void * src, size_t num )
{

    memcpy( dest, src, num );

  return (dest);
}

/*****************************************************************************
*  Function: LoadFlashImage
*
*  Purpose:  This subroutine loads an image from flash into the Nios II 
*  memory map.  It decodes boot records in the format produced from the 
*  elf2flash utility, and loads the image as directed by those records.  
*  The format of the boot record is described in the text of the application 
*  note.
* 
*  The input operand, "image" is expected to be the image selector indicating
*  which flash image, 1 or 2, should be loaded.
*
*****************************************************************************/
alt_u32 LoadFlashImage ( int image )
{
  alt_u8 *next_flash_byte;
  alt_u32 length;
  alt_u32 address;
  
  next_flash_byte = (alt_u8 *)flash_image_ptr_1 + 32;

  /*
   * Flash images are not guaranteed to be word-aligned within the flash 
   * memory, so a word-by-word copy loop should not be used.
   * 
   * The "memcpy()" function works well to copy non-word-aligned data, and 
   * it is relativly small, so that's what we'll use.
   */
   
  // Get the first 4 bytes of the boot record, which should be a length record
  CopyFromFlash( (void*)(&length), (void*)(next_flash_byte), (size_t)(4) );
  next_flash_byte += 4;
  
  // Now loop until we get an entry record, or a halt recotd
  while( (length != 0) && (length != 0xffffffff) )
  {
    // Get the next 4 bytes of the boot record, which should be an address 
    // record
    CopyFromFlash( (void*)(&address), (void*)(next_flash_byte), (size_t)(4) );
    next_flash_byte += 4;
    
    // Copy the next "length" bytes to "address"
    CopyFromFlash( (void*)(address), (void*)(next_flash_byte), (size_t)(length) );
    next_flash_byte += length;
    
    // Get the next 4 bytes of the boot record, which now should be another 
    // length record
    CopyFromFlash( (void*)(&length), (void*)(next_flash_byte), (size_t)(4) );
    next_flash_byte += 4;
  }
  
  // "length" was read as either 0x0 or 0xffffffff, which means we are done 
  // copying.
  if( length == 0xffffffff )
  {
    // We read a HALT record, so return a 0
    return 0;
  }
  else // length == 0x0
  {
    // We got an entry record, so read the next 4 bytes for the entry address
    CopyFromFlash( (void*)(&address), (void*)(next_flash_byte), (size_t)(4) );
    next_flash_byte += 4;
    
    // Return the entry point address
    return address;
  }
}

/******************************************************************************
 *                                                                             *
 * License Agreement                                                           *
 *                                                                             *
 * Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
 * All rights reserved.                                                        *
 *                                                                             *
 * Permission is hereby granted, free of charge, to any person obtaining a     *
 * copy of this software and associated documentation files (the "Software"),  *
 * to deal in the Software without restriction, including without limitation   *
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
 * and/or sell copies of the Software, and to permit persons to whom the       *
 * Software is furnished to do so, subject to the following conditions:        *
 *                                                                             *
 * The above copyright notice and this permission notice shall be included in  *
 * all copies or substantial portions of the Software.                         *
 *                                                                             *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
 * DEALINGS IN THE SOFTWARE.                                                   *
 *                                                                             *
 * This agreement shall be governed in all respects by the laws of the State   *
 * of California and by the laws of the United States of America.              *
 * Altera does not recommend, suggest or require that this reference design    *
 * file be used in conjunction or combination with any other product.          *
 ******************************************************************************/
